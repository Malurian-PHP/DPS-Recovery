<?php $__env->startSection('content'); ?>

<?php if(isset($nameResults)): ?>
<section class="page-section">
    <div class="row">
        <div class="col-md-12">
            <div class="main-card mb-3 card p-5">
                <div class="card-header">Found <?php echo e($nameResults->count()); ?> results.
                
                    <div class="btn-actions-pane-right">
                        <div role="group" class="btn-group-sm btn-group">
                            
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="align-middle mb-0 table table-borderless table-striped table-hover">
                        <thead>
                        <tr>
                            <th class="text-center">Last Name</th>
                            
                            <th class="text-center">Zip Code</th>
                            <th class="text-center">Case Status</th>
                            <th class="text-center">Offense</th>
                            <th class="text-center">Date</th>
                            <th class="text-center">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $nameResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td class="text-center text-muted"><?php echo e($result->caseNameLast); ?></td>
                                        
                                        <td class="text-center"><?php echo e($result->zip->adrsZip); ?></td>
                                        <td class="text-center">
                                            <?php if( $result->caseSecStatus == 'skiptrace'): ?>
                                            <div class="badge badge-danger">
                                                <?php echo e($result->caseSecStatus); ?>

                                            </div>
                                            <?php else: ?>

                                            <div class="badge badge-success">
                                                <?php echo e($result->caseSecStatus); ?>

                                            </div>

                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center"><?php echo e($result->caseNarrative); ?></td>
                                        <td class="text-center">
                                            <?php if( $result->caseDate == ''): ?>
                                            <div class="">
                                                No Date Recorded
                                            </div>
                                            <?php else: ?>

                                            Due <?php echo e($result->caseDate->diffForHumans()); ?>


                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <button type="button" id="PopoverCustomT-1" class="btn btn-primary btn-sm"> <a style="color:white;" href="<?php echo e(url('pay/'. $result->caseUID)); ?>">Make Payment</a></button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php else: ?>
<section class="page-section">
    <div class="row">
        <div class="col-md-12">
            <div class="main-card mb-3 card p-5">
                <div class="card-header">Found <?php echo e($idResults->count()); ?> results.
                
                    <div class="btn-actions-pane-right">
                        <div role="group" class="btn-group-sm btn-group">
                            
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="align-middle mb-0 table table-borderless table-striped table-hover">
                        <thead>
                        <tr>
                            <th class="text-center">Last Name</th>
                            
                            <th class="text-center">Zip Code</th>
                            <th class="text-center">Case Status</th>
                            <th class="text-center">Offense</th>
                            <th class="text-center">Date</th>
                            <th class="text-center">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $idResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td class="text-center text-muted"><?php echo e($result->user->caseNameLast); ?></td>
                                    
                                    <td class="text-center"><?php echo e($result->user->zip->adrsZip); ?></td>
                                    <td class="text-center">
                                        <?php if( $result->user->caseSecStatus == 'skiptrace'): ?>
                                        <div class="badge badge-danger">
                                            <?php echo e($result->user->caseSecStatus); ?>

                                        </div>
                                        <?php else: ?>

                                        <div class="badge badge-success">
                                            <?php echo e($result->user->caseSecStatus); ?>

                                        </div>

                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center"><?php echo e($result->user->caseNarrative); ?></td>
                                    <td class="text-center">
                                        <?php if( $result->user->caseDate == ''): ?>
                                        <div class="">
                                            No Date Recorded
                                        </div>
                                        <?php else: ?>

                                        Due <?php echo e($result->user->caseDate->diffForHumans()); ?>


                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <button type="button" id="PopoverCustomT-1" class="btn btn-primary btn-sm"> <a style="color:white;" href="<?php echo e(url('pay/'. $result->user->caseUID)); ?>">Make Payment</a></button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\dps\resources\views/search.blade.php ENDPATH**/ ?>