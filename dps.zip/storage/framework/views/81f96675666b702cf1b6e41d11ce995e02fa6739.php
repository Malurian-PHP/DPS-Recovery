<?php $__env->startSection('content'); ?>

<section class="page-section">
    <?php if($user == '' ): ?>
        No User
    <?php else: ?>
    <div class="row">
        <div class="container">
            <div class="card text-center">
                <div class="card-header">
                    Welcome <?php echo e($user->caseNameFirst); ?> <?php echo e($user->caseNameLast); ?>

                </div>
                <div class="card-body">
                    <h5 class="card-title">Please Confirm <span style="color: red; font-weight: bold;">
                        <?php echo e($user->letter_id->ltrhistBatchId); ?>/<?php echo e($user->letter_id->ltrhistLtrId); ?>

                    </span> is your Letter ID</h5>
                    <p class="card-text">Also confirm the fee you're about to pay is $<?php echo e($user->balance->balAmtCrntBal); ?>.</p>
                    <a href="#" class="btn btn-primary">Pay $<?php echo e($user->balance->balAmtCrntBal); ?></a>
                </div>
                <div class="card-footer text-muted">
                     <?php if( $user->caseDate == ''): ?>
                        <div class="">
                            No Date Recorded
                        </div>
                    <?php else: ?>

                        Due <?php echo e($user->caseDate->diffForHumans()); ?>


                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\dps\resources\views/payment.blade.php ENDPATH**/ ?>