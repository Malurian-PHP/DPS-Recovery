<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tblppafees extends Model
{
    protected $fillable = [];
}
